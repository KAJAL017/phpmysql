<?php 
include('./main/link.php');
?>


<?php 
include('./main/sidebar.php');
?>

<div class="layout-page">

    <?php 
include('./main/header.php');
?>
    <div class="content-wrapper">

        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <!-- Form Separator -->
                <div class="col-xxl">
                    <div class="card mb-4">
                        <h5 class="card-header">Update User</h5>
                        <form class="card-body" method="post">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="multicol-username">Id</label>
                                <div class="col-sm-9">
                                    <input type="text" id="multicol-username" class="form-control" placeholder="Search Id" name="searchid"  autocomplete="off">

                                    <input type="hidden" name="userid" value="">     
                                </div>
                            </div>
                            <div class="pt-4">
                                <div class="row justify-content-end">
                                    <div class="col-sm-9">
                                        <!-- <button type="submit" class="btn btn-success me-sm-2 me-1" name="updateuser">Update</button>                                      -->
                                            <!-- <button type="reset" class="btn btn-label-secondary">Cancel</button> -->
                                          
                                            <button type="submit" class="btn btn-primary me-sm-2 me-1" name="search">Submit</button>
                                            <button type="reset" class="btn btn-label-secondary">Cancel</button>
                                  
                                    </div>
                                </div>
                            </div>
                        </form>
                        <?php 
    if(isset($_POST['search'])){
    $searchid =$_POST['searchid'];
    $sql="SELECT * FROM `users` WHERE id ={$searchid}";
    // $sql="SELECT * FROM `users` WHERE `id`='$userid'";
    $data = mysqli_query($db,$sql);
    // $searchdata = mysqli_fetch_array($data);
    if(mysqli_num_rows($data)>0){
        while($row = mysqli_fetch_assoc($data)){ ?>
         <form class="card-body" method="post">
                            <h6 class="mb-b fw-normal">1. Account Details</h6>
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="multicol-username">Username</label>
                                <div class="col-sm-9">
                                    <input type="text" id="multicol-username" class="form-control" placeholder="john.doe" name="username" value="<?php echo $row['username']?>">

                                    <input type="hidden" name="userid" value="<?php echo $row['id']?>">
                                        
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="multicol-email">Email</label>
                                <div class="col-sm-9">
                                    <div class="input-group input-group-merge">
                                        <input type="text" id="multicol-email" class="form-control" placeholder="john.doe" aria-label="john.doe"   name="useremail"  aria-describedby="multicol-email2"  value="<?php echo $row['useremail']?>">  
                                        <span class="input-group-text" id="multicol-email2">@example.com</span>
                                    </div>
                                </div>
                            </div>
                            <div class="row form-password-toggle">
                                <label class="col-sm-3 col-form-label" for="multicol-password">Password</label>
                                <div class="col-sm-9">
                                    <div class="input-group input-group-merge">
                                        <input type="password" id="multicol-password" class="form-control"
                                            placeholder="············" aria-describedby="multicol-password2" name="userpass" value="<?php echo $row['userpass']?>">
                                        <span class="input-group-text cursor-pointer" id="multicol-password2"><i
                                                class="bx bx-hide"></i></span>
                                    </div>
                                </div>
                            </div>
                            <hr class="my-4 mx-n4">
                            <h6 class="mb-3 fw-normal">2. Personal Info</h6>
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="multicol-full-name">Full Name</label>
                                <div class="col-sm-9">
                                    <input type="text" id="multicol-full-name" class="form-control"
                                        placeholder="John Doe" name="personal_name" value="">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="multicol-country">Country</label>
                                <div class="col-sm-9">
                                    <div class="position-relative">
                                        <select id="multicol-country"
                                            class="select2 form-select select2-hidden-accessible"
                                            data-allow-clear="true" data-select2-id="multicol-country" tabindex="-1"
                                            aria-hidden="true" name="usercountry" value="">
                                            <option value="" data-select2-id="2">Select</option>
                                            <option value="Australia">Australia</option>
                                            <option value="Bangladesh">Bangladesh</option>
                                            <option value="Belarus">Belarus</option>
                                            <option value="Brazil">Brazil</option>
                                            <option value="Canada">Canada</option>
                                            <option value="China">China</option>
                                            <option value="France">France</option>
                                            <option value="Germany">Germany</option>
                                            <option value="India">India</option>
                                            <option value="Indonesia">Indonesia</option>
                                            <option value="Israel">Israel</option>
                                            <option value="Italy">Italy</option>
                                            <option value="Japan">Japan</option>
                                            <option value="Korea">Korea, Republic of</option>
                                            <option value="Mexico">Mexico</option>
                                            <option value="Philippines">Philippines</option>
                                            <option value="Russia">Russian Federation</option>
                                            <option value="South Africa">South Africa</option>
                                            <option value="Thailand">Thailand</option>
                                            <option value="Turkey">Turkey</option>
                                            <option value="Ukraine">Ukraine</option>
                                            <option value="United Arab Emirates">United Arab Emirates</option>
                                            <option value="United Kingdom">United Kingdom</option>
                                            <option value="United States">United States</option>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-3 col-form-label" for="multicol-phone">Phone No</label>
                                <div class="col-sm-9">
                                    <input type="text" id="multicol-phone" class="form-control phone-mask"
                                        placeholder="658 799 8941" aria-label="658 799 8941" name="user_phone" value="<?php echo $row['user_phone']?>">
                                </div>
                            </div>
                            <div class="pt-4">
                                <div class="row justify-content-end">
                                    <div class="col-sm-9">
                                        <button type="submit" class="btn btn-success me-sm-2 me-1" name="updateuser">Update</button>                                     
                                            <button type="reset" class="btn btn-label-secondary">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </form>

        <?php }
    }
    
}

?>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <?php 
include('./main/footer.php');
?>