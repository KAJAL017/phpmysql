<?php 
include('./main/link.php');
include('./main/query.php');
include('./main/sidebar.php');
?>

<?php 
$update="";
$id ="";
$first_name ="";
$last_name ="";
$last_name ="";
$user_name ="";
$password ="";
$role ="";

if(isset($_GET['editbtn'])){
    $userid=$_GET['editbtn'];
    $sql="SELECT * FROM `user` WHERE user_id={$userid}";
    $update=true;
    $data = mysqli_query($db,$sql);
    $row =  mysqli_fetch_array($data);

    $id = $row['user_id'];
    $first_name = $row['first_name'];
    $last_name = $row['last_name'];
    $last_name = $row['last_name'];
    $user_name = $row['user_name'];
    $password = $row['password'];
    $role = $row['role'];




}



?>
<div class="layout-page">

    <?php 
include('./main/header.php');
?>
    <div class="content-wrapper">

        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <!-- Form Separator -->
                <div class="col-xxl">
                    <div class="card mb-4">
                        <h5 class="card-header">Add User</h5>

                        <form class="card-body" method="post" action="main/query.php">
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="multicol-firstname">First Name</label>
                                <div class="col-sm-9">
                                    <input type="text" id="multicol-firstname" class="form-control"
                                        placeholder="Fisrt Name" name="firstname" value="<?php echo  $first_name?>">
                                    <input type="hidden" name="userid" value="<?php echo  $id?>">

                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="multicol-email">Last Name</label>
                                <div class="col-sm-9">
                                    <div class="input-group input-group-merge">
                                        <input type="text" id="multicol-email" class="form-control"
                                            placeholder="Last Name" name="lastname" value="<?php echo  $last_name?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-3 col-form-label" for="multicol-email">User Name</label>
                                <div class="col-sm-9">
                                    <div class="input-group input-group-merge">
                                        <input type="text" id="multicol-email" class="form-control"
                                            placeholder="User Name" name="username" value="<?php echo $last_name?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row form-password-toggle">
                                <label class="col-sm-3 col-form-label" for="multicol-password">Password</label>
                                <div class="col-sm-9">
                                    <div class="input-group input-group-merge">
                                        <input type="password" id="multicol-password" class="form-control"
                                            placeholder="············" aria-describedby="multicol-password2"
                                            name="userpass">
                                        <span class="input-group-text cursor-pointer" id="multicol-password2"
                                            value="<?php echo $user_name ?>"><i class="bx bx-hide"></i></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <label class="col-sm-3 col-form-label" for="multicol-role">Role</label>
                                <div class="col-sm-9">
                                    <div class="position-relative">
                                        <select id="multicol-role" class="select2 form-select select2-hidden-accessible"
                                            data-allow-clear="true" data-select2-id="multicol-role" tabindex="-1"
                                            aria-hidden="true" name="userrole" >
                                            <option <?php if($role == '1') { ?> selected="selected"<?php } ?> value="1">Admin</option>
                                            <option <?php if($role == '2') { ?> selected="selected"<?php } ?> value="2">Normal</option>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <div class="pt-4">
                                <div class="row justify-content-end">
                                    <div class="col-sm-9">
                                        <?php 
                                        if($update==true){
                                            echo '<button type="reset" class="btn btn-label-secondary me-2">Cancel</button>
                                                  <button type="submit" class="btn btn-success me-sm-2 me-1" name="updateuser">Update</button>';
                                        }
                                        else{
                                            echo '<button type="reset" class="btn btn-label-secondary">Cancel</button>
                                                  <button type="submit" class="btn btn-primary me-sm-2 me-1" name="saveuser">Submit</button>';
                                        }
                                        ?>
                                
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <?php 
include('./main/footer.php');
?>