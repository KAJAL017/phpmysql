<?php 
include('./main/link.php');
include('./main/query.php');
?>
<?php 



?>

<?php 
include('./main/sidebar.php');
?>

<div class="layout-page">

    <?php 
include('./main/header.php');
?>
    <div class="content-wrapper">

        <div class="container-xxl flex-grow-1 container-p-y">
       
        <div class="card">
  <h5 class="card-header">All Users Data</h5>
  <div class="table-responsive text-nowrap">
    <table class="table table-hover  text-center">
      <thead>
        <tr>
          <th>USER ID</th>
          <th>FIRST NAME</th>
          <th>LAST NAME</th>
          <th>USER NAME</th>
          <th>PASSWORD</th>
          <th>ROLE</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody class="table-border-bottom-0 text-center">
                       
       <?php 
       
       $fetch_data="SELECT * FROM `user` WHERE 1 ";
       $data = mysqli_query($db,$fetch_data);
       while( $row = mysqli_fetch_assoc($data)){ ?>
       <tr>
         <td><?php echo $row['user_id']?></td>
         <td><?php echo $row['first_name']?></td>
         <td><?php echo $row['last_name']?></td>
         <td><?php echo $row['user_name']?></td>
         <td><?php echo $row['password']?></td>
         <td><?php 
         if($row['role']== '1')
          { ?>ADMIN<?php } else{
            echo 'NORMAL';
          }
          
          ?></td>
         <td>
            <div class="dropdown">
              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                <i class="bx bx-dots-vertical-rounded"></i></button>
              <div class="dropdown-menu">
                <a class="dropdown-item" href="index.php?editbtn=<?php echo $row['user_id'] ?>"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                <a class="dropdown-item" href="main/query.php?deletebtn=<?php echo $row['user_id'] ?>"><i class="bx bx-trash me-1"></i> Delete</a>
              </div>
            </div>
          </td>
       </tr>
       <?php } ?>
       
      </tbody>
    </table>
  </div>
</div>
        </div>
    </div>
    <?php 
include('./main/footer.php');
?>