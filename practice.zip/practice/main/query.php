<?php 
include('link.php');

if(isset($_POST['saveuser'])){

    $firstname = mysqli_real_escape_string($db,$_POST['firstname']);
    $lastname = mysqli_real_escape_string($db,$_POST['lastname']);
    $username = mysqli_real_escape_string($db,$_POST['username']);
    $userpass = mysqli_real_escape_string($db,md5($_POST['userpass']));
    $userrole = mysqli_real_escape_string($db,$_POST['userrole']);
    
    // Check User Name Already start
    
    $select_username="SELECT * FROM `user` WHERE `user_name`='$username'";
    $check_username = mysqli_query($db,$select_username);
    
    if( mysqli_num_rows($check_username)>0){
      echo "<p style='color:red'>User Name Already Exists</p>";
      return false;
    }
    else{
        $insert_query="INSERT INTO `user`( `first_name`, `last_name`, `user_name`, `password`, `role`) VALUES ('$username','$lastname','$username','$userpass','$userrole')";
        if(mysqli_query($db,$insert_query)){
            header('location:../index.php');
        }
    }
    // Check User Name Already end
    
    
    }


   if(isset($_GET['deletebtn'])){
    $userid = $_GET['deletebtn'];
    $delete_query="DELETE FROM `user` WHERE User_id='{$userid}'";
    mysqli_query($db,$delete_query) or die('connection failed');
    header('location:../userlist.php');
   }


   if(isset($_POST['updateuser'])){

    $userid = $_POST['userid'];
    $firstname = mysqli_real_escape_string($db,$_POST['firstname']);
    $lastname = mysqli_real_escape_string($db,$_POST['lastname']);
    $username = mysqli_real_escape_string($db,$_POST['username']);
    $userpass = mysqli_real_escape_string($db,md5($_POST['userpass']));
    $userrole = mysqli_real_escape_string($db,$_POST['userrole']);

    $update_sql="UPDATE `user` SET `first_name`='$firstname',`last_name`='$lastname',`user_name`='$username',`password`='$userpass',`role`='$userrole' WHERE `user_id`='{$userid}'";
    mysqli_query($db,$update_sql);
    header('location:../userlist.php');
   }





?>