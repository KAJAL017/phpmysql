<?php 
$db = mysqli_connect('localhost','root','','news_paper') or die('connetion failed:'.mysqli_connect_error());

$path="../../../php/practice/files/assets";
$main="../../../php/practice/main";

?>