
<!-- Footer -->
<footer class="content-footer footer bg-footer-theme">
  <div class="container-fluid d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
    <div class="mb-2 mb-md-0">
      © <script>
      document.write(new Date().getFullYear())
      </script>
      , made with ❤️ by <a href="https://pixinvent.com/" target="_blank" class="footer-link fw-semibold">PIXINVENT</a>
    </div>
    <div>
      
      <a href="https://themeforest.net/licenses/standard" class="footer-link me-4" target="_blank">License</a>
      <a href="https://1.envato.market/pixinvent_portfolio" target="_blank" class="footer-link me-4">More Themes</a>
      
      <a href="https://pixinvent.com/demo/frest-clean-bootstrap-admin-dashboard-template/documentation-bs5/" target="_blank" class="footer-link me-4">Documentation</a>
      
      
      <a href="https://pixinvent.ticksy.com/" target="_blank" class="footer-link d-none d-sm-inline-block">Support</a>
      
    </div>
  </div>
</footer>
<!-- / Footer -->

          
          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->
      </div>
      <!-- / Layout page -->
    </div>

    
    
    <!-- Overlay -->
   
    
    
    
    <!-- Drag Target Area To SlideIn Menu On Small Screens -->
    <div class="drag-target"></div>
    
  </div>
  <!-- / Layout wrapper -->


  

  <!-- Core JS -->
  <!-- build:js assets/vendor/js/core.js -->

  <script src="<?php echo $path?>/vendor/libs/jquery/jquery.js"></script>
  <script src="<?php echo $path?>/vendor/libs/popper/popper.js"></script>
  <script src="<?php echo $path?>/vendor/js/bootstrap.js"></script>
  <script src="<?php echo $path?>/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
  
  <script src="<?php echo $path?>/vendor/libs/hammer/hammer.js"></script>
  

  <script src="<?php echo $path?>/vendor/libs/i18n/i18n.js"></script>
  <script src="<?php echo $path?>/vendor/libs/typeahead-js/typeahead.js"></script>
  <script src="<?php echo $path?>/vendor/js/menu.js"></script>
  <!-- endbuild -->

  <!-- Vendors JS -->
  <script src="<?php echo $path?>/vendor/libs/apex-charts/apexcharts.js"></script>
  <script src="<?php echo $path?>/vendor/libs/cleavejs/cleave-phone.js"></script>
  <script src="<?php echo $path?>/vendor/libs/moment/moment.js"></script>
  <script src="<?php echo $path?>/vendor/libs/select2/select2.js"></script>
  <script src="<?php echo $path?>/vendor/libs/flatpickr/flatpickr.js"></script>
  <!-- Main JS -->
  <script src="<?php echo $path?>/js/main.js"></script>

  <!-- Page JS -->
  <script src="<?php echo $path?>/js/dashboards-analytics.js"></script>
</body>


<!-- Mirrored from pixinvent.com/demo/frest-clean-bootstrap-admin-dashboard-template/html/vertical-menu-template/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 20 Nov 2022 15:52:37 GMT -->
</html>
